<?php
/**
 * Customer requests (new-customer intake) + approve/reject.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tap_ops_request_out( array $r ) {
	return array(
		'id'             => (string) $r['id'],
		'firstName'      => (string) $r['first_name'],
		'lastName'       => (string) $r['last_name'],
		'companyName'    => (string) $r['company_name'],
		'title'          => (string) $r['title'],
		'street'         => (string) $r['street'],
		'street2'        => (string) $r['street2'],
		'city'           => (string) $r['city'],
		'state'          => (string) $r['state'],
		'zip'            => (string) $r['zip'],
		'phone'          => (string) $r['phone'],
		'email'          => (string) $r['email'],
		'services'       => array_values( (array) tap_ops_json_out( $r['services'], array() ) ),
		'trainings'      => array_values( (array) tap_ops_json_out( $r['trainings'], array() ) ),
		'dateNeeded'     => tap_ops_date_out( $r['date_needed'] ),
		'additionalInfo' => (string) $r['additional_info'],
		'status'         => (string) $r['status'],
		'reviewedById'   => tap_ops_id_out( $r['reviewed_by_id'] ),
		'reviewedByName' => tap_ops_str_or_null( $r['reviewed_by_name'] ),
		'reviewedAt'     => tap_ops_iso( $r['reviewed_at'] ),
		'reviewNote'     => tap_ops_str_or_null( $r['review_note'] ),
		'customerId'     => tap_ops_id_out( $r['customer_id'] ),
		'createdAt'      => tap_ops_iso( $r['created_at'] ),
		'source'         => (string) $r['source'],
		'leadStatus'     => isset( $r['lead_status'] ) && '' !== $r['lead_status'] ? (string) $r['lead_status'] : 'New',
		'paymentStatus'  => isset( $r['payment_status'] ) && '' !== $r['payment_status'] ? (string) $r['payment_status'] : 'None',
		'budgetQuote'    => isset( $r['budget_quote'] ) && null !== $r['budget_quote'] ? (float) $r['budget_quote'] : null,
		'amountPaid'     => isset( $r['amount_paid'] ) ? (float) $r['amount_paid'] : 0.0,
		'paymentProofs'  => array_values( (array) tap_ops_json_out( isset( $r['payment_proofs'] ) ? $r['payment_proofs'] : null, array() ) ),
		'payments'       => array_values( (array) tap_ops_json_out( isset( $r['payments'] ) ? $r['payments'] : null, array() ) ),
	);
}

function tap_ops_get_request_row( $id ) {
	global $wpdb;
	$t = tap_ops_t( 'requests' );
	return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", (int) $id ), ARRAY_A ); // phpcs:ignore
}

/** Clean a list of strings (services/trainings). */
function tap_ops_string_list( $value ) {
	if ( is_string( $value ) ) {
		$value = '' === trim( $value ) ? array() : array( $value );
	}
	if ( ! is_array( $value ) ) {
		return null;
	}
	$out = array();
	foreach ( $value as $v ) {
		if ( is_scalar( $v ) ) {
			$s = tap_ops_text( $v, 255 );
			if ( '' !== $s ) {
				$out[] = $s;
			}
		}
	}
	return array_values( array_unique( $out ) );
}

/**
 * Create a request row from camelCase data (shared by the REST intake and Gravity Forms).
 *
 * @param array $data   Fields as in the contract. Anything missing becomes '' / today.
 * @param bool  $strict When true, required fields are enforced (REST); when false nothing is rejected (GF).
 * @return array|WP_Error Request API object.
 */
function tap_ops_create_request( array $data, $strict, $default_source = 'api' ) {
	global $wpdb;

	$text = function ( $k, $max = 255 ) use ( $data ) {
		return isset( $data[ $k ] ) ? tap_ops_text( $data[ $k ], $max ) : '';
	};
	$row = array(
		'first_name'      => $text( 'firstName', 100 ),
		'last_name'       => $text( 'lastName', 100 ),
		'company_name'    => $text( 'companyName' ),
		'title'           => $text( 'title' ),
		'street'          => $text( 'street' ),
		'street2'         => $text( 'street2' ),
		'city'            => $text( 'city', 100 ),
		'state'           => $text( 'state', 100 ),
		'zip'             => $text( 'zip', 20 ),
		'phone'           => $text( 'phone', 50 ),
		'email'           => isset( $data['email'] ) && is_string( $data['email'] ) ? sanitize_email( trim( $data['email'] ) ) : '',
		'additional_info' => isset( $data['additionalInfo'] ) ? tap_ops_textarea( $data['additionalInfo'], 20000 ) : '',
	);

	// Leads added by staff (source "manual") only need a name, company and a way
	// to reach them; the public quote form keeps the full set of required fields.
	$manual = isset( $data['source'] ) && 'manual' === $data['source'];

	if ( $strict ) {
		$required = array(
			'first_name'   => 'firstName',
			'last_name'    => 'lastName',
			'company_name' => 'companyName',
		);
		if ( ! $manual ) {
			$required += array(
				'street' => 'street',
				'city'   => 'city',
				'state'  => 'state',
				'zip'    => 'zip',
				'phone'  => 'phone',
				'email'  => 'email',
			);
		}
		foreach ( $required as $col => $key ) {
			if ( '' === $row[ $col ] ) {
				return tap_ops_err( 422, 'validation', "$key is required." );
			}
		}
		if ( $manual && '' === $row['phone'] && '' === $row['email'] ) {
			return tap_ops_err( 422, 'validation', 'phone or email is required.' );
		}
		if ( ( ! $manual || '' !== $row['email'] ) && ! is_email( $row['email'] ) ) {
			return tap_ops_err( 422, 'validation', 'email is not valid.' );
		}
	}

	$services  = tap_ops_string_list( isset( $data['services'] ) ? $data['services'] : array() );
	$trainings = tap_ops_string_list( isset( $data['trainings'] ) ? $data['trainings'] : array() );
	if ( null === $services || null === $trainings ) {
		if ( $strict ) {
			return tap_ops_err( 422, 'validation', 'services and trainings must be arrays of strings.' );
		}
		$services  = (array) $services;
		$trainings = (array) $trainings;
	}

	$date = gmdate( 'Y-m-d' );
	if ( isset( $data['dateNeeded'] ) && '' !== $data['dateNeeded'] && null !== $data['dateNeeded'] ) {
		$v = tap_ops_valid_date( $data['dateNeeded'] );
		if ( null === $v ) {
			if ( $strict ) {
				return tap_ops_err( 422, 'validation', 'dateNeeded must be YYYY-MM-DD.' );
			}
		} else {
			$date = $v;
		}
	}

	$source = isset( $data['source'] ) ? tap_ops_text( $data['source'], 100 ) : '';

	$row['services']    = tap_ops_json_in( $services );
	$row['trainings']   = tap_ops_json_in( $trainings );
	$row['date_needed'] = $date;
	$row['status']      = 'PENDING';
	$row['source']      = '' === $source ? $default_source : $source;
	$row['created_at']  = tap_ops_now();

	if ( false === $wpdb->insert( tap_ops_t( 'requests' ), $row ) ) {
		return tap_ops_err( 500, 'db_error', 'Could not save request.' );
	}
	$out = tap_ops_request_out( tap_ops_get_request_row( $wpdb->insert_id ) );
	if ( 'manual' !== $row['source'] ) {
		tap_ops_notify_new_request( $out );
	}
	return $out;
}

/**
 * Who hears about a new quote request: the addresses in TAP_OPS_NOTIFY_EMAILS (comma separated) if set,
 * otherwise every TAP admin, otherwise the site's administrators. Filter: tap_ops_new_request_recipients.
 */
function tap_ops_new_request_recipients() {
	$emails = array();
	if ( defined( 'TAP_OPS_NOTIFY_EMAILS' ) && TAP_OPS_NOTIFY_EMAILS ) {
		$emails = array_map( 'trim', explode( ',', (string) TAP_OPS_NOTIFY_EMAILS ) );
	} else {
		$users = get_users( array( 'role' => 'tap_admin' ) );
		if ( ! $users ) {
			$users = get_users( array( 'role' => 'administrator' ) );
		}
		foreach ( $users as $u ) {
			$emails[] = $u->user_email;
		}
	}
	$emails = array_values( array_unique( array_filter( $emails, 'is_email' ) ) );
	return (array) apply_filters( 'tap_ops_new_request_recipients', $emails );
}

/**
 * Emails the admins about a new quote request. Runs after the response has gone back to the visitor,
 * so a slow mail server can never hold up (or break) the quote form.
 */
function tap_ops_notify_new_request( array $r ) {
	add_action(
		'shutdown',
		function () use ( $r ) {
			if ( function_exists( 'fastcgi_finish_request' ) ) {
				fastcgi_finish_request();
			}
			$to = tap_ops_new_request_recipients();
			if ( ! $to ) {
				return;
			}
			// Never let a flood of requests become a flood of emails: at most 20 notifications an hour (the requests are still saved).
			if ( tap_ops_throttle_count( 'notify-new-request' ) >= 20 ) {
				return;
			}
			tap_ops_throttle_hit( 'notify-new-request', HOUR_IN_SECONDS );
			$name   = trim( $r['firstName'] . ' ' . $r['lastName'] );
			$who    = '' !== $r['companyName'] ? $r['companyName'] : $name;
			$wanted = implode( ', ', array_merge( (array) $r['services'], (array) $r['trainings'] ) );
			$lines  = array_filter(
				array(
					'Name: ' . $name,
					'' !== $r['companyName'] ? 'Company: ' . $r['companyName'] : '',
					'' !== $r['email'] ? 'Email: ' . $r['email'] : '',
					'' !== $r['phone'] ? 'Phone: ' . $r['phone'] : '',
					'' !== $wanted ? 'Wants: ' . $wanted : '',
					! empty( $r['dateNeeded'] ) ? 'Needed by: ' . $r['dateNeeded'] : '',
				)
			);
			$body   = "A new quote request just came in.\n\n" . implode( "\n", $lines );
			if ( '' !== (string) $r['additionalInfo'] ) {
				$body .= "\n\nNotes: " . ( function_exists( 'mb_substr' ) ? mb_substr( (string) $r['additionalInfo'], 0, 500 ) : substr( (string) $r['additionalInfo'], 0, 500 ) );
			}
			$portal = defined( 'TAP_OPS_PORTAL_URL' ) ? trim( (string) TAP_OPS_PORTAL_URL ) : '';
			if ( '' !== $portal ) {
				$body .= "\n\nReview it in the portal: " . untrailingslashit( $portal ) . '/leads';
			}
			wp_mail( $to, 'New quote request: ' . $who, $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );
		}
	);
}

function tap_ops_h_request_create( WP_REST_Request $request ) {
	$body = tap_ops_body( $request );
	// The public quote form: at most 5 requests an hour from one address (the portal passes it as clientIp).
	$ip = tap_ops_forwarded_ip( $body );
	if ( $ip ) {
		if ( tap_ops_throttle_count( 'quote:' . $ip ) >= 5 ) {
			return tap_ops_err( 429, 'too_many_requests', 'Too many requests from your network. Please try again later or call us.' );
		}
		tap_ops_throttle_hit( 'quote:' . $ip, HOUR_IN_SECONDS );
	}
	return tap_ops_create_request( $body, true, 'api' );
}

/** Staff edits to a lead from the dashboard: status, payment, quote, date. */
function tap_ops_h_request_patch( WP_REST_Request $request ) {
	global $wpdb;
	$id = tap_ops_int_id( $request['id'] );
	if ( ! tap_ops_get_request_row( $id ) ) {
		return tap_ops_err( 404, 'not_found', 'Request not found.' );
	}
	$b = tap_ops_body( $request );
	$d = array();
	if ( array_key_exists( 'paymentProofs', $b ) ) {
		$proofs = tap_ops_proof_list( $b['paymentProofs'] );
		if ( null === $proofs ) {
			return tap_ops_err( 422, 'validation', 'paymentProofs must be up to 10 image/PDF links.' );
		}
		$d['payment_proofs'] = tap_ops_json_in( $proofs );
	}
	if ( array_key_exists( 'payments', $b ) ) {
		$pay = tap_ops_payments_in( $b['payments'] );
		if ( null === $pay ) {
			return tap_ops_err( 422, 'validation', 'payments is invalid.' );
		}
		$d['payments'] = tap_ops_json_in( $pay );
	}
	if ( array_key_exists( 'services', $b ) ) {
		$list = tap_ops_string_list( $b['services'] );
		if ( null === $list ) {
			return tap_ops_err( 422, 'validation', 'services must be an array of strings.' );
		}
		$d['services'] = tap_ops_json_in( $list );
	}
	if ( array_key_exists( 'leadStatus', $b ) ) {
		if ( ! in_array( $b['leadStatus'], tap_ops_lead_statuses(), true ) ) {
			return tap_ops_err( 422, 'validation', 'leadStatus is invalid.' );
		}
		$d['lead_status'] = $b['leadStatus'];
	}
	if ( array_key_exists( 'paymentStatus', $b ) ) {
		if ( ! in_array( $b['paymentStatus'], tap_ops_payment_statuses(), true ) ) {
			return tap_ops_err( 422, 'validation', 'paymentStatus is invalid.' );
		}
		$d['payment_status'] = $b['paymentStatus'];
	}
	if ( array_key_exists( 'budgetQuote', $b ) ) {
		$m = tap_ops_money_in( $b['budgetQuote'] );
		if ( false === $m ) {
			return tap_ops_err( 422, 'validation', 'budgetQuote must be a non-negative number.' );
		}
		$d['budget_quote'] = $m;
	}
	if ( array_key_exists( 'amountPaid', $b ) ) {
		$m = tap_ops_money_in( $b['amountPaid'] );
		if ( false === $m ) {
			return tap_ops_err( 422, 'validation', 'amountPaid must be a non-negative number.' );
		}
		$d['amount_paid'] = null === $m ? 0 : $m;
	}
	if ( array_key_exists( 'dateNeeded', $b ) ) {
		$v = tap_ops_valid_date( $b['dateNeeded'] );
		if ( null === $v ) {
			return tap_ops_err( 422, 'validation', 'dateNeeded must be YYYY-MM-DD.' );
		}
		$d['date_needed'] = $v;
	}
	if ( $d ) {
		$wpdb->update( tap_ops_t( 'requests' ), $d, array( 'id' => $id ) );
	}
	return tap_ops_request_out( tap_ops_get_request_row( $id ) );
}

function tap_ops_h_requests_list() {
	global $wpdb;
	$t = tap_ops_t( 'requests' );
	return array_map( 'tap_ops_request_out', (array) $wpdb->get_results( "SELECT * FROM $t ORDER BY created_at DESC, id DESC LIMIT 10000", ARRAY_A ) ); // phpcs:ignore
}

function tap_ops_h_requests_pending_count() {
	global $wpdb;
	$t = tap_ops_t( 'requests' );
	return array( 'count' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE status = %s", 'PENDING' ) ) ); // phpcs:ignore
}

/**
 * Atomically move a request out of PENDING. Only one caller can win.
 */
function tap_ops_claim_request( $id, $status, $note = null ) {
	global $wpdb;
	$t     = tap_ops_t( 'requests' );
	$actor = tap_ops_actor();
	$n     = $wpdb->query(
		$wpdb->prepare(
			"UPDATE $t SET status = %s, lead_status = %s, reviewed_by_id = %d, reviewed_by_name = %s, reviewed_at = %s, review_note = %s WHERE id = %d AND status = 'PENDING'", // phpcs:ignore
			$status,
			'APPROVED' === $status ? 'Converted' : 'Not Interested',
			$actor ? (int) $actor->ID : 0,
			$actor ? (string) $actor->display_name : '',
			tap_ops_now(),
			(string) $note,
			(int) $id
		)
	);
	return 1 === (int) $n;
}

function tap_ops_h_request_approve( WP_REST_Request $request ) {
	global $wpdb;
	$id  = tap_ops_int_id( $request['id'] );
	$row = tap_ops_get_request_row( $id );
	if ( ! $row ) {
		return tap_ops_err( 404, 'not_found', 'Request not found.' );
	}
	if ( ! tap_ops_claim_request( $id, 'APPROVED' ) ) {
		return tap_ops_err( 409, 'already_reviewed', 'This request has already been reviewed.' );
	}

	$site    = trim( $row['street'] . ( '' !== $row['street2'] ? ', ' . $row['street2'] : '' ) );
	$contact = trim( $row['first_name'] . ' ' . $row['last_name'] );
	if ( '' !== $row['title'] ) {
		$contact .= ', ' . $row['title'];
	}
	$nn = function ( $v ) {
		return '' === $v ? null : $v;
	};
	$ok = $wpdb->insert(
		tap_ops_t( 'customers' ),
		array(
			'name'       => '' !== $row['company_name'] ? $row['company_name'] : ( '' !== $contact ? $contact : 'Unnamed customer' ),
			'site'       => $nn( $site ),
			'city'       => $nn( $row['city'] ),
			'state'      => $nn( $row['state'] ),
			'zip'        => $nn( $row['zip'] ),
			'contact'    => $nn( $contact ),
			'email'      => $nn( $row['email'] ),
			'phone'      => $nn( $row['phone'] ),
			'services'       => $row['services'],
			'service_date'   => $nn( tap_ops_date_out( $row['date_needed'] ) ),
			'payment_status' => '' !== (string) $row['payment_status'] ? $row['payment_status'] : 'None',
			'project_value'  => $row['budget_quote'],
			'payment_proofs' => $row['payment_proofs'],
			'payments'       => $row['payments'],
			'amount_paid'    => $row['amount_paid'],
			'created_at'     => tap_ops_now(),
		)
	);
	if ( false === $ok ) {
		// Roll the claim back so the request can be retried.
		$wpdb->update( tap_ops_t( 'requests' ), array( 'status' => 'PENDING', 'lead_status' => $row['lead_status'], 'reviewed_by_id' => null, 'reviewed_by_name' => null, 'reviewed_at' => null ), array( 'id' => $id ) );
		return tap_ops_err( 500, 'db_error', 'Could not create the customer.' );
	}
	$cid = (int) $wpdb->insert_id;
	$wpdb->update( tap_ops_t( 'requests' ), array( 'customer_id' => $cid ), array( 'id' => $id ) );
	return array( 'customerId' => (string) $cid );
}

/** Admin: delete a lead for good. A lead that was converted into a customer stays (the customer is built on it). */
function tap_ops_h_request_delete( WP_REST_Request $request ) {
	global $wpdb;
	$id  = tap_ops_int_id( $request['id'] );
	$row = tap_ops_get_request_row( $id );
	if ( ! $row ) {
		return tap_ops_err( 404, 'not_found', 'Request not found.' );
	}
	if ( 'APPROVED' === $row['status'] || ! empty( $row['customer_id'] ) ) {
		return tap_ops_err( 409, 'converted', 'This lead was converted into a customer, so it cannot be deleted.' );
	}
	$wpdb->delete( tap_ops_t( 'requests' ), array( 'id' => $id ) );
	return array( 'ok' => true );
}

function tap_ops_h_request_reject( WP_REST_Request $request ) {
	$id = tap_ops_int_id( $request['id'] );
	if ( ! tap_ops_get_request_row( $id ) ) {
		return tap_ops_err( 404, 'not_found', 'Request not found.' );
	}
	$b    = tap_ops_body( $request );
	$note = isset( $b['note'] ) ? tap_ops_textarea( $b['note'], 2000 ) : '';
	if ( ! tap_ops_claim_request( $id, 'REJECTED', $note ) ) {
		return tap_ops_err( 409, 'already_reviewed', 'This request has already been reviewed.' );
	}
	return array( 'ok' => true );
}
