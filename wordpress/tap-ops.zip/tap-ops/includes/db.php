<?php
/**
 * Schema (dbDelta) and roles.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tap_ops_install_schema() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$previous_version = (string) get_option( 'tap_ops_db_version', '' );

	$c = $wpdb->get_charset_collate();
	$t = function ( $n ) {
		return tap_ops_t( $n );
	};

	$sql   = array();
	$sql[] = "CREATE TABLE {$t('customers')} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL,
  site varchar(255) DEFAULT NULL,
  city varchar(100) DEFAULT NULL,
  state varchar(100) DEFAULT NULL,
  zip varchar(20) DEFAULT NULL,
  contact varchar(255) DEFAULT NULL,
  email varchar(255) DEFAULT NULL,
  phone varchar(50) DEFAULT NULL,
  services longtext,
  service_date date DEFAULT NULL,
  assigned_auditor_id bigint(20) unsigned DEFAULT NULL,
  assigned_at datetime DEFAULT NULL,
  payment_status varchar(30) NOT NULL DEFAULT 'None',
  project_value decimal(12,2) DEFAULT NULL,
  progress_status varchar(30) NOT NULL DEFAULT 'In progress',
  payment_proofs longtext,
  payments longtext,
  amount_paid decimal(12,2) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY name (name)
) $c;";

	$sql[] = "CREATE TABLE {$t('templates')} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL,
  category varchar(20) NOT NULL DEFAULT 'GENERAL',
  tpl_fields longtext,
  approval_required tinyint(1) NOT NULL DEFAULT 0,
  report_style varchar(20) NOT NULL DEFAULT 'MODERN',
  report_accent_color varchar(50) DEFAULT NULL,
  report_logo longtext,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY name (name)
) $c;";

	$sql[] = "CREATE TABLE {$t('audits')} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  doc_number varchar(40) NOT NULL,
  template_id bigint(20) unsigned NOT NULL,
  customer_id bigint(20) unsigned NOT NULL,
  inspector_id bigint(20) unsigned DEFAULT NULL,
  title varchar(255) NOT NULL,
  score int(11) DEFAULT NULL,
  critical_fail tinyint(1) NOT NULL DEFAULT 0,
  draft tinyint(1) NOT NULL DEFAULT 0,
  pending_approval tinyint(1) NOT NULL DEFAULT 0,
  needs_correction tinyint(1) NOT NULL DEFAULT 0,
  ready_to_submit tinyint(1) NOT NULL DEFAULT 0,
  correction_note text,
  report_sent tinyint(1) NOT NULL DEFAULT 0,
  audit_date datetime NOT NULL,
  responses longtext,
  notes longtext,
  photos longtext,
  signature longtext,
  share_token varchar(40) DEFAULT NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY doc_number (doc_number),
  UNIQUE KEY share_token (share_token),
  KEY customer_id (customer_id),
  KEY template_id (template_id),
  KEY audit_date (audit_date)
) $c;";

	$sql[] = "CREATE TABLE {$t('schedules')} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  title varchar(255) NOT NULL,
  template_id bigint(20) unsigned NOT NULL,
  customer_id bigint(20) unsigned NOT NULL,
  frequency varchar(20) NOT NULL,
  start_date date NOT NULL,
  active tinyint(1) NOT NULL DEFAULT 1,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY template_id (template_id),
  KEY customer_id (customer_id)
) $c;";

	$sql[] = "CREATE TABLE {$t('actions')} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  title varchar(255) NOT NULL,
  description longtext,
  priority varchar(20) NOT NULL DEFAULT 'MEDIUM',
  status varchar(20) NOT NULL DEFAULT 'OPEN',
  due_date date DEFAULT NULL,
  finding_label varchar(255) DEFAULT NULL,
  audit_id bigint(20) unsigned DEFAULT NULL,
  customer_id bigint(20) unsigned NOT NULL,
  assignee_id bigint(20) unsigned DEFAULT NULL,
  created_by_id bigint(20) unsigned DEFAULT NULL,
  resolved_at datetime DEFAULT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY audit_id (audit_id),
  KEY customer_id (customer_id)
) $c;";

	$sql[] = "CREATE TABLE {$t('events')} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  audit_id bigint(20) unsigned NOT NULL,
  user_id bigint(20) unsigned DEFAULT NULL,
  user_name varchar(255) DEFAULT NULL,
  message text NOT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY audit_id (audit_id)
) $c;";

	$sql[] = "CREATE TABLE {$t('requests')} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  first_name varchar(100) NOT NULL DEFAULT '',
  last_name varchar(100) NOT NULL DEFAULT '',
  company_name varchar(255) NOT NULL DEFAULT '',
  title varchar(255) NOT NULL DEFAULT '',
  street varchar(255) NOT NULL DEFAULT '',
  street2 varchar(255) NOT NULL DEFAULT '',
  city varchar(100) NOT NULL DEFAULT '',
  state varchar(100) NOT NULL DEFAULT '',
  zip varchar(20) NOT NULL DEFAULT '',
  phone varchar(50) NOT NULL DEFAULT '',
  email varchar(255) NOT NULL DEFAULT '',
  services longtext,
  trainings longtext,
  date_needed date NOT NULL,
  additional_info longtext,
  status varchar(20) NOT NULL DEFAULT 'PENDING',
  reviewed_by_id bigint(20) unsigned DEFAULT NULL,
  reviewed_by_name varchar(255) DEFAULT NULL,
  reviewed_at datetime DEFAULT NULL,
  review_note text,
  customer_id bigint(20) unsigned DEFAULT NULL,
  source varchar(100) NOT NULL DEFAULT '',
  lead_status varchar(30) NOT NULL DEFAULT 'New',
  payment_status varchar(30) NOT NULL DEFAULT 'None',
  budget_quote decimal(12,2) DEFAULT NULL,
  amount_paid decimal(12,2) NOT NULL DEFAULT 0,
  payment_proofs longtext,
  payments longtext,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY status (status)
) $c;";

	$sql[] = "CREATE TABLE {$t('email_templates')} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(120) NOT NULL,
  subject varchar(255) NOT NULL,
  body longtext,
  attach_report tinyint(1) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id)
) $c;";

	$sql[] = "CREATE TABLE {$t('doc_sequences')} (
  category varchar(20) NOT NULL,
  seq int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY  (category)
) $c;";

	foreach ( $sql as $statement ) {
		dbDelta( $statement );
	}

	tap_ops_seed_email_templates();

	// v2 added lead/customer tracking columns: give leads that were already
	// decided a matching status, and let existing customers inherit their lead's services.
	if ( '1' === $previous_version ) {
		$rq = tap_ops_t( 'requests' );
		$cu = tap_ops_t( 'customers' );
		$wpdb->query( "UPDATE $rq SET lead_status = 'Converted' WHERE status = 'APPROVED'" ); // phpcs:ignore
		$wpdb->query( "UPDATE $rq SET lead_status = 'Not Interested' WHERE status = 'REJECTED'" ); // phpcs:ignore
		$wpdb->query( "UPDATE $cu c INNER JOIN $rq r ON r.customer_id = c.id SET c.services = r.services, c.service_date = r.date_needed" ); // phpcs:ignore
	}

	// v8: reports that were already emailed or shared with the customer (and not sent back since) get the "already sent" flag.
	if ( (int) $previous_version < 8 ) {
		$au = tap_ops_t( 'audits' );
		$ev = tap_ops_t( 'events' );
		$wpdb->query( // phpcs:ignore
			"UPDATE $au a SET a.report_sent = 1
			WHERE a.report_sent = 0 AND a.draft = 0 AND a.pending_approval = 0 AND a.ready_to_submit = 0
			AND EXISTS (
				SELECT 1 FROM $ev e
				WHERE e.audit_id = a.id
				AND ( e.message LIKE 'Email sent to % with the report attached' OR e.message = 'Public report link created' )
				AND NOT EXISTS (
					SELECT 1 FROM $ev c
					WHERE c.audit_id = a.id AND c.created_at > e.created_at
					AND ( c.message LIKE 'Correction requested:%' OR c.message = 'Sent back for correction' )
				)
			)"
		);
	}

	update_option( 'tap_ops_db_version', TAP_OPS_DB_VERSION );
}

function tap_ops_register_roles() {
	// Capability `read` only: these accounts have no wp-admin power; all access is through the REST plugin.
	if ( ! get_role( 'tap_admin' ) ) {
		add_role( 'tap_admin', 'TAP Admin', array( 'read' => true ) );
	}
	if ( ! get_role( 'tap_inspector' ) ) {
		add_role( 'tap_inspector', 'TAP Inspector', array( 'read' => true ) );
	}
}

function tap_ops_maybe_upgrade() {
	if ( get_option( 'tap_ops_db_version' ) !== TAP_OPS_DB_VERSION ) {
		tap_ops_install_schema();
	}
	if ( ! get_role( 'tap_admin' ) || ! get_role( 'tap_inspector' ) ) {
		tap_ops_register_roles();
	}
}
